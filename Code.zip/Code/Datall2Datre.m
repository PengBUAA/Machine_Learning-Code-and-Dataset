function [Datre]=Datall2Datre(Datall)

group = 1;

for i = 1:height(Datall)
    if Datall(i,1) == 1
        Datall(i,1) = group;
    end
    if (Datall(i,1) == 0) && (Datall(i+1,1)==1)
        group = group + 1;
    end
end

Datall = Datall(Datall(:,1) ~= 0, :);  %% 删除移动中的点 即删除zupt=0的点 

[~, ~, ic] = unique(Datall(:,1)); %%求各点信号强度平均值
for j = 1:width(Datall)
    Datre(:,j) = accumarray(ic, Datall(:,j), [], @mean);
end

end