function [Datall] =Datin(wid_s_e,mid_s_e)

zupt_datin = importdata('Dat/zupt.txt');
zupt_zero = zeros(1,1);   %%矩阵相接处增加全零行
zupt.wid1 = [zupt_datin(wid_s_e(1):wid_s_e(2));zupt_zero;zupt_datin(wid_s_e(5)+1:wid_s_e(6))];
zupt.widst = [zupt_datin(wid_s_e(2)+1:wid_s_e(3));zupt_zero;zupt_datin(wid_s_e(4)+1:wid_s_e(5))];
zupt.wid2 = zupt_datin(wid_s_e(3)+1:wid_s_e(4));
zupt.mid1 = zupt_datin(mid_s_e(1):mid_s_e(2));
zupt.midst = zupt_datin(mid_s_e(2)+1:mid_s_e(3));
zupt.mid2 = zupt_datin(mid_s_e(3)+1:mid_s_e(4));

loc_datin=load('Dat/location1.txt');
loc_zero = zeros(1,3);
loc_datin = loc_datin - loc_datin(wid_s_e(1),:);   %% 转换到起点为原点0,0
loc.wid1 = [loc_datin(wid_s_e(1):wid_s_e(2),:);loc_zero;loc_datin(wid_s_e(5)+1:wid_s_e(6),:)];
loc.wid1(:,3) = 0;
loc.widst = [loc_datin(wid_s_e(2)+1:wid_s_e(3),:);loc_zero;loc_datin(wid_s_e(4)+1:wid_s_e(5),:)];
loc.wid2 = loc_datin(wid_s_e(3)+1:wid_s_e(4),:);
loc.wid2(:,3) = 3.6;
loc.mid1 = loc_datin(mid_s_e(1):mid_s_e(2),:);
loc.mid1(:,3) = 0;
loc.midst = loc_datin(mid_s_e(2)+1:mid_s_e(3),:);
loc.mid2 = loc_datin(mid_s_e(3)+1:mid_s_e(4),:);
loc.mid2(210:1013,1) = loc.mid2(210:1013,1) + 0.4;
loc.mid2(:,3) = 3.6;

ori_datin = load('Dat/ori.txt');
ori_zero = zeros(1,3);
ori.wid1 = [ori_datin(wid_s_e(1):wid_s_e(2),:);ori_zero;ori_datin(wid_s_e(5)+1:wid_s_e(6),:)];
ori.widst = [ori_datin(wid_s_e(2)+1:wid_s_e(3),:);ori_zero;ori_datin(wid_s_e(4)+1:wid_s_e(5),:)];
ori.wid2 = ori_datin(wid_s_e(3)+1:wid_s_e(4),:);
ori.mid1 = ori_datin(mid_s_e(1):mid_s_e(2),:);
ori.midst = ori_datin(mid_s_e(2)+1:mid_s_e(3),:);
ori.mid2 = ori_datin(mid_s_e(3)+1:mid_s_e(4),:);

mag_datin = importdata('Dat/magall.txt');
mag_zero = zeros(1,3);
mag.wid1 = [mag_datin(wid_s_e(1):wid_s_e(2),:);mag_zero;mag_datin(wid_s_e(5)+1:wid_s_e(6),:)];
mag.widst = [mag_datin(wid_s_e(2)+1:wid_s_e(3),:);mag_zero;mag_datin(wid_s_e(4)+1:wid_s_e(5),:)];
mag.wid2 = mag_datin(wid_s_e(3)+1:wid_s_e(4),:);
mag.mid1 = mag_datin(mid_s_e(1):mid_s_e(2),:);
mag.midst = mag_datin(mid_s_e(2)+1:mid_s_e(3),:);
mag.mid2 = mag_datin(mid_s_e(3)+1:mid_s_e(4),:);

acc_datin = load('Dat/acc_u.txt');
acc_zero = zeros(1,3);
acc.wid1 = [acc_datin(wid_s_e(1):wid_s_e(2),:);acc_zero;acc_datin(wid_s_e(5)+1:wid_s_e(6),:)];
acc.widst = [acc_datin(wid_s_e(2)+1:wid_s_e(3),:);acc_zero;acc_datin(wid_s_e(4)+1:wid_s_e(5),:)];
acc.wid2 = acc_datin(wid_s_e(3)+1:wid_s_e(4),:);
acc.mid1 = acc_datin(mid_s_e(1):mid_s_e(2),:);
acc.midst = acc_datin(mid_s_e(2)+1:mid_s_e(3),:);
acc.mid2 = acc_datin(mid_s_e(3)+1:mid_s_e(4),:);

press_datin = importdata('Dat/press.txt');
press_wid_ori = press_datin(wid_s_e(1));
press_mid_ori = press_datin(mid_s_e(1));
press_datin(wid_s_e(1):wid_s_e(6),:) = press_datin(wid_s_e(1):wid_s_e(6),:) - press_wid_ori;
press_datin(mid_s_e(1):mid_s_e(4),:) = press_datin(mid_s_e(1):mid_s_e(4),:) - press_mid_ori;

press_zero = zeros(1,1);
press.wid1 = [press_datin(wid_s_e(1):wid_s_e(2),:);press_zero;press_datin(wid_s_e(5)+1:wid_s_e(6),:)];
press.widst = [press_datin(wid_s_e(2)+1:wid_s_e(3),:);press_zero;press_datin(wid_s_e(4)+1:wid_s_e(5),:)];
press.wid2 = press_datin(wid_s_e(3)+1:wid_s_e(4),:);
press.mid1 = press_datin(mid_s_e(1):mid_s_e(2),:);
press.midst = press_datin(mid_s_e(2)+1:mid_s_e(3),:);
press.mid2 = press_datin(mid_s_e(3)+1:mid_s_e(4),:);


Datall.wid1(:,1) = zupt.wid1;    Datall.widst(:,1) = zupt.widst;   Datall.wid2(:,1) = zupt.wid2;   
Datall.mid1(:,1) = zupt.mid1;    Datall.midst(:,1) = zupt.midst;   Datall.mid2(:,1) = zupt.mid2; 

Datall.wid1(:,2:4) = loc.wid1;    Datall.widst(:,2:4) = loc.widst;   Datall.wid2(:,2:4) = loc.wid2;   
Datall.mid1(:,2:4) = loc.mid1;    Datall.midst(:,2:4) = loc.midst;   Datall.mid2(:,2:4) = loc.mid2;

Datall.wid1(:,5:7) = mag.wid1;    Datall.widst(:,5:7) = mag.widst;   Datall.wid2(:,5:7) = mag.wid2;   
Datall.mid1(:,5:7) = mag.mid1;    Datall.midst(:,5:7) = mag.midst;   Datall.mid2(:,5:7) = mag.mid2;

Datall.wid1(:,8:10) = acc.wid1;    Datall.widst(:,8:10) = acc.widst;   Datall.wid2(:,8:10) = acc.wid2;   
Datall.mid1(:,8:10) = acc.mid1;    Datall.midst(:,8:10) = acc.midst;   Datall.mid2(:,8:10) = acc.mid2;

Datall.wid1(:,11) = press.wid1;    Datall.widst(:,11) = press.widst;   Datall.wid2(:,11) = press.wid2;   
Datall.mid1(:,11) = press.mid1;    Datall.midst(:,11) = press.midst;   Datall.mid2(:,11) = press.mid2;


% sm = 1;   % 0:不降噪. 1:平滑降噪     论文里未降噪
% span = 10; degree = 1;
% %降噪
% if sm==1
%     for i = 2:width(Datall.wid1)
%         Datall.wid1(:,5) = smooth(Datall.wid1(:,5),span,'sgolay',degree);
%     end
% end





% %%%%%% 画图测试 降噪前后对比
% 
% tempall.wid = [Datall.wid1;Datall.widst;Datall.wid2];
% tempall.mag = [mag.wid1;mag.widst;mag.wid2];
% 
% sm = 1;   % 0:不降噪. 1:平滑降噪
% span = 10; degree = 1;
% %降噪
% if sm==1
%     for i = 1:width(tempall.wid)
%         tempall.wid(:,i) = smooth(tempall.wid(:,i),span,'sgolay',degree);
% %         tempall.mag(:,i) = smooth(tempall.mag(:,i),span,'sgolay',degree);
%     end
% end
% 
% hh = tiledlayout(3, 1,'TileSpacing','none','Padding','none'); % 定义3*1子图
% set(gcf, 'unit','centimeters','position',[40,10,8,10],'Color', 'w');  % 页面设置白底,并指定窗口的位置和大小
% x=(1:5377)';
% h1 = nexttile(1);
% plot(x,tempall.mag(:,1),'-','color','b','linewidth',1.0); % 手机自己算的横滚角
% hold on
% plot(x,tempall.wid(:,5),'-','color','r','linewidth',1.0);
% % set(gca,'xticklabel',[]);
% set(gca,'xgrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);% 灰色格网线
% set(gca,'Ygrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);
% set(gca,'XMinorTick','on'); % X轴打开密集坐标格网
% set(gca,'YMinorTick','on'); % Y轴打开密集坐标格网
% ylabel(h1,'Magx(uT)','FontSize',13,'FontWeight','normal','Fontname','Arial');
% xlim([0 5380])
% 
% 
% h2 = nexttile(2);
% plot(x,tempall.mag(:,2),'-','color','b','linewidth',1.0); % 手机自己算的俯仰角
% hold on
% plot(x,tempall.wid(:,6),'-','color','r','linewidth',1.0);
% % set(gca,'xticklabel',[]);
% set(gca,'xgrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);% 灰色格网线
% set(gca,'Ygrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);
% set(gca,'XMinorTick','on'); % X轴打开密集坐标格网
% set(gca,'YMinorTick','on'); % Y轴打开密集坐标格网
% ylabel(h2,'Magy(uT)','FontSize',13,'FontWeight','normal','Fontname','Arial');
% xlim([0 5380])
% 
% 
% h3 = nexttile(3);
% plot(x,tempall.mag(:,3),'-','color','b','linewidth',1.0); % 手机自己算的航向角
% hold on
% plot(x,tempall.wid(:,7),'-','color','r','linewidth',1.0);
% % set(gca,'xTickLabel',get(gca,'xTick'));
% set(gca,'xgrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);% 灰色格网线
% set(gca,'Ygrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);
% set(gca,'XMinorTick','on'); % X轴打开密集坐标格网
% set(gca,'YMinorTick','on'); % Y轴打开密集坐标格网
% ylabel(h3,'Magz(uT)','FontSize',13,'FontWeight','normal','Fontname','Arial');
% % xlabel(h3,'Time (s)','FontSize',10,'FontWeight','normal','Fontname','Arial');
% 
% title(hh,' ');
% leg=legend({'原始数据','均值滤波'},'Location','north','FontSize',13,'Orientation','horizontal','FontWeight','normal','box','on'...
%    );
% leg.ItemTokenSize = [12,18]; %% 默认是[30,18],改小一些可以缩短legend线的长度
% xlim([0 5380])
