clc;clear;close all;

%% 数据导入
format long;
set(groot, 'defaultAxesFontSize', 13, 'defaultAxesLineWidth', 1.2, 'defaultLegendFontSize', 12);
widstart=206; widend=5580;       wid_s_e = [206;1492;1915;3632;4148;5580];         %206-1492-1915-3632-4148-5580
midstart=5597; midend=8760;      mid_s_e = [5597;7210;7747;8760];         %5597-7210-7747-8760    8765-9680-10092-11146(end)
% midstart=8765; midend=11146;      mid_s_e = [8765;9680;10092;11146];
%导入zupt、位置、磁场、加速度、气压，并降噪
[Datall] =Datin(wid_s_e,mid_s_e);

%% 导入WIFI（已降噪） 
[Wifi_wid,Wifi_mid]=Datin_wifi(wid_s_e,mid_s_e);
%%
wid_s_e = wid_s_e - 205;
mid_s_e = mid_s_e - 5596;
%% 分解导出的WiFi
wifi_zero = zeros(1,width(Wifi_wid.data));   %%矩阵相接处增加全零行
wifi.wid1=[Wifi_wid.data(wid_s_e(1):wid_s_e(2),:);wifi_zero;Wifi_wid.data(wid_s_e(5)+1:wid_s_e(6),:)];
wifi.widst = [Wifi_wid.data(wid_s_e(2)+1:wid_s_e(3),:);wifi_zero;Wifi_wid.data(wid_s_e(4)+1:wid_s_e(5),:)];
wifi.wid2 = Wifi_wid.data(wid_s_e(3)+1:wid_s_e(4),:);
wifi.mid1 = Wifi_mid.data(mid_s_e(1):mid_s_e(2),:);
wifi.midst = Wifi_mid.data(mid_s_e(2)+1:mid_s_e(3),:);
wifi.mid2 = Wifi_mid.data(mid_s_e(3)+1:mid_s_e(4),:);
%% 将WiFi导入指纹库 13+WiFi
Datall.wid1(:,13:13+width(Wifi_wid.data)-1) = wifi.wid1;     Datall.mid1(:,13:13+width(Wifi_wid.data)-1) = wifi.mid1;
Datall.widst(:,13:13+width(Wifi_wid.data)-1) = wifi.widst;   Datall.midst(:,13:13+width(Wifi_wid.data)-1) = wifi.midst;
Datall.wid2(:,13:13+width(Wifi_wid.data)-1) = wifi.wid2;     Datall.mid2(:,13:13+width(Wifi_wid.data)-1) = wifi.mid2;

%% 取出各采样静止点数据
[Datre.wid1]=Datall2Datre(Datall.wid1);     [Datre.widst]=Datall2Datre(Datall.widst);     [Datre.wid2]=Datall2Datre(Datall.wid2);
[Datre.mid1]=Datall2Datre(Datall.mid1);     [Datre.midst]=Datall2Datre(Datall.midst);     [Datre.mid2]=Datall2Datre(Datall.mid2);
%% 调整楼梯段的高度
[~,maxi] = max(Datre.widst(:,4));
Datre.widst(1:maxi,4) = linspace(0,3.6,maxi);
Datre.widst(maxi+1:size(Datre.widst,1),4) = linspace(3.6,0,size(Datre.widst,1)-maxi);
Datre.midst(1:size(Datre.midst,1),4) = linspace(0,3.6,size(Datre.midst,1));
%% 取出b系磁场和加速度
mag.bx_wid1 = Datre.wid1(:,5);     mag.by_wid1 = Datre.wid1(:,6);       mag.bz_wid1 = Datre.wid1(:,7);
acc.x_wid1 = Datre.wid1(:,8);      acc.y_wid1 = Datre.wid1(:,9);        acc.z_wid1 = Datre.wid1(:,10);

mag.bx_widst = Datre.widst(:,5);   mag.by_widst = Datre.widst(:,6);     mag.bz_widst = Datre.widst(:,7);
acc.x_widst = Datre.widst(:,8);    acc.y_widst = Datre.widst(:,9);      acc.z_widst = Datre.widst(:,10);

mag.bx_wid2 = Datre.wid2(:,5);     mag.by_wid2 = Datre.wid2(:,6);       mag.bz_wid2 = Datre.wid2(:,7);
acc.x_wid2 = Datre.wid2(:,8);      acc.y_wid2 = Datre.wid2(:,9);        acc.z_wid2 = Datre.wid2(:,10);

mag.bx_mid1 = Datre.mid1(:,5);     mag.by_mid1 = Datre.mid1(:,6);       mag.bz_mid1 = Datre.mid1(:,7);
acc.x_mid1 = Datre.mid1(:,8);      acc.y_mid1 = Datre.mid1(:,9);        acc.z_mid1 = Datre.mid1(:,10);

mag.bx_midst = Datre.midst(:,5);   mag.by_midst = Datre.midst(:,6);     mag.bz_midst = Datre.midst(:,7);
acc.x_midst = Datre.midst(:,8);    acc.y_midst = Datre.midst(:,9);      acc.z_midst = Datre.midst(:,10);

mag.bx_mid2 = Datre.mid2(:,5);     mag.by_mid2 = Datre.mid2(:,6);       mag.bz_mid2 = Datre.mid2(:,7);
acc.x_mid2 = Datre.mid2(:,8);      acc.y_mid2 = Datre.mid2(:,9);        acc.z_mid2 = Datre.mid2(:,10);

%% 姿态解算 B转N
[mag.nx_wid1,mag.ny_wid1,mag.nz_wid1,yaw_rad]=MagB2MagN(mag.bx_wid1,mag.by_wid1,mag.bz_wid1,acc.x_wid1,acc.y_wid1,acc.z_wid1);
[mag.nx_widst,mag.ny_widst,mag.nz_widst,yaw_rad]=MagB2MagN(mag.bx_widst,mag.by_widst,mag.bz_widst,acc.x_widst,acc.y_widst,acc.z_widst);
[mag.nx_wid2,mag.ny_wid2,mag.nz_wid2,yaw_rad]=MagB2MagN(mag.bx_wid2,mag.by_wid2,mag.bz_wid2,acc.x_wid2,acc.y_wid2,acc.z_wid2);

[mag.nx_mid1,mag.ny_mid1,mag.nz_mid1,yaw_rad]=MagB2MagN(mag.bx_mid1,mag.by_mid1,mag.bz_mid1,acc.x_mid1,acc.y_mid1,acc.z_mid1);
[mag.nx_midst,mag.ny_midst,mag.nz_midst,yaw_rad]=MagB2MagN(mag.bx_midst,mag.by_midst,mag.bz_midst,acc.x_midst,acc.y_midst,acc.z_midst);
[mag.nx_mid2,mag.ny_mid2,mag.nz_mid2,yaw_rad]=MagB2MagN(mag.bx_mid2,mag.by_mid2,mag.bz_mid2,acc.x_mid2,acc.y_mid2,acc.z_mid2);
%% 567放n系磁场并降噪
Datre.wid1(:,5)=mag.nx_wid1;  Datre.widst(:,5)=mag.nx_widst;   Datre.wid2(:,5)=mag.nx_wid2;
Datre.wid1(:,6)=mag.ny_wid1;  Datre.widst(:,6)=mag.ny_widst;   Datre.wid2(:,6)=mag.ny_wid2;
Datre.wid1(:,7)=mag.nz_wid1;  Datre.widst(:,7)=mag.nz_widst;   Datre.wid2(:,7)=mag.nz_wid2;

Datre.mid1(:,5)=mag.nx_mid1;  Datre.midst(:,5)=mag.nx_midst;   Datre.mid2(:,5)=mag.nx_mid2;
Datre.mid1(:,6)=mag.ny_mid1;  Datre.midst(:,6)=mag.ny_midst;   Datre.mid2(:,6)=mag.ny_mid2;
Datre.mid1(:,7)=mag.nz_mid1;  Datre.midst(:,7)=mag.nz_midst;   Datre.mid2(:,7)=mag.nz_mid2;

sm = 0;   % 0:不降噪. 1:平滑降噪
span = 10; degree = 1;
%降噪
if sm==1
    for i = 5:7
        Datall.wid1(:,i) = smooth(Datall.wid1(:,i),span,'sgolay',degree);
        Datall.widst(:,i) = smooth(Datall.widst(:,i),span,'sgolay',degree);
        Datall.wid2(:,i) = smooth(Datall.wid2(:,i),span,'sgolay',degree);
        Datall.mid1(:,i) = smooth(Datall.mid1(:,i),span,'sgolay',degree);
        Datall.midst(:,i) = smooth(Datall.midst(:,i),span,'sgolay',degree);
        Datall.mid2(:,i) = smooth(Datall.mid2(:,i),span,'sgolay',degree);
    end
end
%% 生成边界并插点

% 绘制多边形
poly.wid1 = polyshape(Datre.wid1(:,2),Datre.wid1(:,3));
poly.widst = polyshape(Datre.widst(:,2),Datre.widst(:,3));
poly.wid2 = polyshape(Datre.wid2(:,2),Datre.wid2(:,3));

% 获取多边形边界
[Elim.wid1,Nlim.wid1] = boundingbox(poly.wid1);
[Elim.widst,Nlim.widst] = boundingbox(poly.widst);
[Elim.wid2,Nlim.wid2] = boundingbox(poly.wid2 );
%
Emin.wid1=Elim.wid1(1);Emax.wid1=Elim.wid1(2);    Nmin.wid1=Nlim.wid1(1);Nmax.wid1=Nlim.wid1(2);
Emin.widst=Elim.widst(1);Emax.widst=Elim.widst(2);    Nmin.widst=Nlim.widst(1);Nmax.widst=Nlim.widst(2);
Emin.wid2=Elim.wid2(1)+0.0001;Emax.wid2=Elim.wid2(2)-0.0001;    Nmin.wid2=Nlim.wid2(1)+0.0001;Nmax.wid2=Nlim.wid2(2)-0.0001;

figure;
hold on;
plot(poly.wid1);
axis equal;

% 取多边形内部点
newPoint.wid1=[Datre.mid1(:,2),Datre.mid1(:,3)];
newPoint.widst=[Datre.midst(:,2),Datre.midst(:,3)];
newPoint.wid2=[Datre.mid2(:,2),Datre.mid2(:,3)];
scatter(newPoint.wid1(:,1),newPoint.wid1(:,2),2.5,'MarkerFaceColor','r','MarkerEdgeColor','r');

%% 对插点插值
% 对待插值点找离它最近的四个点，输出对应点的编号，到这四个点的距离
[Pointre_len,Pointre_num]=Findpoint(newPoint,Datre);

% 反距离内插 插得泛源信号强度
Datnew = Dis_in(Pointre_len,Pointre_num,Datre,newPoint);

% 将位置坐标与插值强度放在一起
Datnew.wid1(:,2:3) = newPoint.wid1;
Datnew.widst(:,2:3) = newPoint.widst;
Datnew.wid2(:,2:3) = newPoint.wid2;

Datnew.midall = [Datnew.wid1;Datnew.widst;Datnew.wid2];
Datre.midall = [Datre.mid1;Datre.midst;Datre.mid2];
%% 插值对比
figure
set(gcf, 'Position', [100, 100, 800, 600]);
subplot(1,3,1);
hold on
box on
plot(Datnew.midall(:,5),'linewidth',2);
% scatter(1:length(Datnew.midall(:,5)),Datnew.midall(:,5));
plot(Datre.midall(:,5),'linewidth',2);
% legend('newpoint','truepoint','Position', [0.8, 0.93, 0.1, 0.05]);
legend('Reference sequence','Interpolated sequence')

set(gca,'xgrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);% 灰色格网线
set(gca,'Ygrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);
set(gca,'XMinorTick','on'); % X轴打开密集坐标格网
set(gca,'YMinorTick','on'); % Y轴打开密集坐标格网
set(gca,'FontSize',13,'FontWeight','normal')

error1 = sqrt(sum((Datnew.midall(:,5) - Datre.midall(:,5)).^2) ./ length(Datre.midall(:,5)));
% error1 = max(abs(Datnew.midall(:,5) - Datre.midall(:,5)));
xlim([0 175])
% string = {strcat('东向磁场真值与插值对比：', ['RMSE=' num2str(error1)])};
string = {'Eastward component'};
title(string)
xlabel('Sampling index')
ylabel('Magnetic field strength(μT)')

subplot(1,3,2);
plot(Datnew.midall(:,6),'linewidth',2);
hold on
plot(Datre.midall(:,6),'linewidth',2);
set(gca,'xgrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);% 灰色格网线
set(gca,'Ygrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);
set(gca,'XMinorTick','on'); % X轴打开密集坐标格网
set(gca,'YMinorTick','on'); % Y轴打开密集坐标格网
set(gca,'FontSize',13,'FontWeight','normal')
error2 = sqrt(sum((Datnew.midall(:,6) - Datre.midall(:,6)).^2) ./ length(Datre.midall(:,6)));
% error2 = max(abs(Datnew.midall(:,6) - Datre.midall(:,6)));
xlim([0 175])
% string = {strcat('北向磁场真值与插值对比：', ['RMSE=' num2str(error2)])};
string = {'Northward component'};
title(string)
xlabel('Sampling index')
ylabel('Magnetic field strength(μT)')
legend('Reference sequence','Interpolated sequence')
subplot(1,3,3);
plot(Datnew.midall(:,7),'linewidth',2);
hold on
plot(Datre.midall(:,7),'linewidth',2);
set(gca,'xgrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);% 灰色格网线
set(gca,'Ygrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);
set(gca,'XMinorTick','on'); % X轴打开密集坐标格网
set(gca,'YMinorTick','on'); % Y轴打开密集坐标格网
set(gca,'FontSize',13,'FontWeight','normal')
error3 = sqrt(sum((Datnew.midall(:,7) - Datre.midall(:,7)).^2) ./ length(Datre.midall(:,7)));
% error3 = max(abs(Datnew.midall(:,7) - Datre.midall(:,7)));
xlim([0 175])
% string = {strcat('天向磁场真值与插值对比：', ['RMSE=' num2str(error3)])};
string = {'Vertical component'};
title(string)
xlabel('Sampling index')
ylabel('Magnetic field strength(μT)')
legend('Reference sequence','Interpolated sequence')
% print(gcf,'-dpng','-r600',[pwd,'\插值比较']); % 输出图片路径
% subplot(4,1,4);
% plot(newPoint(:,7));
% hold on
% plot(Datre_mid.data(:,8));
% set(gca,'xgrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);% 灰色格网线
% set(gca,'Ygrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);
% set(gca,'XMinorTick','on'); % X轴打开密集坐标格网
% set(gca,'YMinorTick','on'); % Y轴打开密集坐标格网
% set(gca,'FontSize',13,'FontWeight','normal','Fontname','Arial')
% title('Mh');
