clc;clear;close all;

%% 数据导入 指纹库 1ZUPT 234XYZ 567Mb 8910acc 11Press 12Light 
format long;
set(groot, 'defaultAxesFontSize', 13, 'defaultAxesLineWidth', 1.2, 'defaultLegendFontSize', 12);
widstart=206; widend=5580;       wid_s_e = [206;1492;1915;3632;4148;5580];         %206-1492-1915-3632-4148-5580
midstart=5597; midend=8760;      mid_s_e = [5597;7210;7747;9680;10092;11146];         %5597-7210-7747-8760    8765-9680-10092-11146(end)
% midstart=8765; midend=11146;      mid_s_e = [8765;9680;10092;11146];
%导入zupt、位置、磁场、加速度、气压，并降噪
[Datall] =Datin(wid_s_e,mid_s_e);

%% 导入WIFI（已降噪） 
[Wifi_wid,Wifi_mid]=Datin_wifi(wid_s_e,mid_s_e);
%%
wid_s_e = wid_s_e - 205;
mid_s_e = mid_s_e - 8764;
%% 分解导出的WiFi
wifi_zero = zeros(1,width(Wifi_wid.data));   %%矩阵相接处增加全零行
wifi.wid1=[Wifi_wid.data(wid_s_e(1):wid_s_e(2),:);wifi_zero;Wifi_wid.data(wid_s_e(5)+1:wid_s_e(6),:)];
wifi.widst = [Wifi_wid.data(wid_s_e(2)+1:wid_s_e(3),:);wifi_zero;Wifi_wid.data(wid_s_e(4)+1:wid_s_e(5),:)];
wifi.wid2 = Wifi_wid.data(wid_s_e(3)+1:wid_s_e(4),:);
wifi.mid1 = Wifi_mid.data(mid_s_e(1):mid_s_e(2),:);
wifi.midst = Wifi_mid.data(mid_s_e(2)+1:mid_s_e(3),:);
wifi.mid2 = Wifi_mid.data(mid_s_e(3)+1:mid_s_e(4),:);
%% 将WiFi导入指纹库 13+WiFi
Datall.wid1(:,13:13+width(Wifi_wid.data)-1) = wifi.wid1;     Datall.mid1(:,13:13+width(Wifi_wid.data)-1) = wifi.mid1;
Datall.widst(:,13:13+width(Wifi_wid.data)-1) = wifi.widst;   Datall.midst(:,13:13+width(Wifi_wid.data)-1) = wifi.midst;
Datall.wid2(:,13:13+width(Wifi_wid.data)-1) = wifi.wid2;     Datall.mid2(:,13:13+width(Wifi_wid.data)-1) = wifi.mid2;
%% 取出各采样静止点数据
[Datre.wid1]=Datall2Datre(Datall.wid1);     [Datre.widst]=Datall2Datre(Datall.widst);     [Datre.wid2]=Datall2Datre(Datall.wid2);
[Datre.mid1]=Datall2Datre(Datall.mid1);     [Datre.midst]=Datall2Datre(Datall.midst);     [Datre.mid2]=Datall2Datre(Datall.mid2);

% % 提取训练集中初始采集时的在起点处的数据放到Datre.wid1的最前 尝试是否可行
% rowsToExtract = (Datall.wid1(:, 1) == 1) & all(Datall.wid1(:, 2:4) == 0, 2);
% Datinit = Datall.wid1(rowsToExtract, :);
% Datinit(:,1) = 0;
% Datre.wid1 = [Datinit;Datre.wid1];
% 
% % 提取测试集中初始采集时的在起点处的数据放到Datre.mid1的最前 尝试是否可行
% rowsToExtract = Datall.mid1(:,1) == 1 & Datall.mid1(:,2) == Datall.mid1(1,2) & Datall.mid1(:,3) == Datall.mid1(1,3) ;
% Datinit = Datall.mid1(rowsToExtract, :);
% Datinit(:,1) = 0;
% Datre.mid1 = [Datinit;Datre.mid1];

% 提取训练集中初始采集时的在起点处的数据放到Datre.mid1的最前 尝试是否可行
rowsToExtract = (Datall.wid1(:, 1) == 1) & all(Datall.wid1(:, 2:4) == 0, 2);
Datinit = Datall.wid1(rowsToExtract, :);
Datinit(:,1) = 0;
Datre.mid1 = [Datinit;Datre.mid1];
%% 调整楼梯段的高度
[~,maxi] = max(Datre.widst(:,4));
Datre.widst(1:maxi,4) = linspace(0,3.6,maxi);
% Datre.widst(maxi+1:length(Datre.widst),4) = linspace(3.6,0,length(Datre.widst)-maxi);
% Datre.midst(1:length(Datre.midst),4) = linspace(0,3.6,length(Datre.midst));
Datre.widst(maxi+1:size(Datre.widst,1),4) = linspace(3.6,0,size(Datre.widst,1)-maxi);
Datre.midst(1:size(Datre.midst,1),4) = linspace(0,3.6,size(Datre.midst,1));
%% 取出b系磁场和加速度
mag.bx_wid1 = Datre.wid1(:,5);     mag.by_wid1 = Datre.wid1(:,6);       mag.bz_wid1 = Datre.wid1(:,7);
acc.x_wid1 = Datre.wid1(:,8);      acc.y_wid1 = Datre.wid1(:,9);        acc.z_wid1 = Datre.wid1(:,10);

mag.bx_widst = Datre.widst(:,5);   mag.by_widst = Datre.widst(:,6);     mag.bz_widst = Datre.widst(:,7);
acc.x_widst = Datre.widst(:,8);    acc.y_widst = Datre.widst(:,9);      acc.z_widst = Datre.widst(:,10);

mag.bx_wid2 = Datre.wid2(:,5);     mag.by_wid2 = Datre.wid2(:,6);       mag.bz_wid2 = Datre.wid2(:,7);
acc.x_wid2 = Datre.wid2(:,8);      acc.y_wid2 = Datre.wid2(:,9);        acc.z_wid2 = Datre.wid2(:,10);

mag.bx_mid1 = Datre.mid1(:,5);     mag.by_mid1 = Datre.mid1(:,6);       mag.bz_mid1 = Datre.mid1(:,7);
acc.x_mid1 = Datre.mid1(:,8);      acc.y_mid1 = Datre.mid1(:,9);        acc.z_mid1 = Datre.mid1(:,10);

mag.bx_midst = Datre.midst(:,5);   mag.by_midst = Datre.midst(:,6);     mag.bz_midst = Datre.midst(:,7);
acc.x_midst = Datre.midst(:,8);    acc.y_midst = Datre.midst(:,9);      acc.z_midst = Datre.midst(:,10);

mag.bx_mid2 = Datre.mid2(:,5);     mag.by_mid2 = Datre.mid2(:,6);       mag.bz_mid2 = Datre.mid2(:,7);
acc.x_mid2 = Datre.mid2(:,8);      acc.y_mid2 = Datre.mid2(:,9);        acc.z_mid2 = Datre.mid2(:,10);

%% 姿态解算 B转N
[mag.nx_wid1,mag.ny_wid1,mag.nz_wid1,yaw_rad]=MagB2MagN(mag.bx_wid1,mag.by_wid1,mag.bz_wid1,acc.x_wid1,acc.y_wid1,acc.z_wid1);
[mag.nx_widst,mag.ny_widst,mag.nz_widst,yaw_rad]=MagB2MagN(mag.bx_widst,mag.by_widst,mag.bz_widst,acc.x_widst,acc.y_widst,acc.z_widst);
[mag.nx_wid2,mag.ny_wid2,mag.nz_wid2,yaw_rad]=MagB2MagN(mag.bx_wid2,mag.by_wid2,mag.bz_wid2,acc.x_wid2,acc.y_wid2,acc.z_wid2);

[mag.nx_mid1,mag.ny_mid1,mag.nz_mid1,yaw_rad]=MagB2MagN(mag.bx_mid1,mag.by_mid1,mag.bz_mid1,acc.x_mid1,acc.y_mid1,acc.z_mid1);
[mag.nx_midst,mag.ny_midst,mag.nz_midst,yaw_rad]=MagB2MagN(mag.bx_midst,mag.by_midst,mag.bz_midst,acc.x_midst,acc.y_midst,acc.z_midst);
[mag.nx_mid2,mag.ny_mid2,mag.nz_mid2,yaw_rad]=MagB2MagN(mag.bx_mid2,mag.by_mid2,mag.bz_mid2,acc.x_mid2,acc.y_mid2,acc.z_mid2);
%% 567放n系磁场并降噪
Datre.wid1(:,5)=mag.nx_wid1;  Datre.widst(:,5)=mag.nx_widst;   Datre.wid2(:,5)=mag.nx_wid2;
Datre.wid1(:,6)=mag.ny_wid1;  Datre.widst(:,6)=mag.ny_widst;   Datre.wid2(:,6)=mag.ny_wid2;
Datre.wid1(:,7)=mag.nz_wid1;  Datre.widst(:,7)=mag.nz_widst;   Datre.wid2(:,7)=mag.nz_wid2;

Datre.mid1(:,5)=mag.nx_mid1;  Datre.midst(:,5)=mag.nx_midst;   Datre.mid2(:,5)=mag.nx_mid2;
Datre.mid1(:,6)=mag.ny_mid1;  Datre.midst(:,6)=mag.ny_midst;   Datre.mid2(:,6)=mag.ny_mid2;
Datre.mid1(:,7)=mag.nz_mid1;  Datre.midst(:,7)=mag.nz_midst;   Datre.mid2(:,7)=mag.nz_mid2;

sm = 1;   % 0:不降噪. 1:平滑降噪
span = 10; degree = 1;
%降噪
if sm==1
    for i = 5:7
        Datall.wid1(:,i) = smooth(Datall.wid1(:,i),span,'sgolay',degree);
        Datall.widst(:,i) = smooth(Datall.widst(:,i),span,'sgolay',degree);
        Datall.wid2(:,i) = smooth(Datall.wid2(:,i),span,'sgolay',degree);
        Datall.mid1(:,i) = smooth(Datall.mid1(:,i),span,'sgolay',degree);
        Datall.midst(:,i) = smooth(Datall.midst(:,i),span,'sgolay',degree);
        Datall.mid2(:,i) = smooth(Datall.mid2(:,i),span,'sgolay',degree);
    end
end
% Datre_wid.data(:,8)=sqrt(Datre_wid.data(:,5).^2+Datre_wid.data(:,6).^2);

%% 生成边界并均匀插点,输出边界和插点的坐标
[poly,newPoint]=NewpointLoc(Datre);
figure;
hold on;
plot(poly.wid2);
axis equal;
scatter(newPoint.wid2(:,1),newPoint.wid2(:,2),2.5,'MarkerFaceColor','r','MarkerEdgeColor','r');
% xlim([-10,10])
% ylim([-1.5,40])
%% 对插点插值
% 对待插值点找离它最近的四个点，输出对应点的编号，到这四个点的距离
[Pointre_len,Pointre_num]=Findpoint(newPoint,Datre);

% 反距离内插 插得泛源信号强度
Datnew = Dis_in(Pointre_len,Pointre_num,Datre,newPoint);

% 将位置坐标与插值强度放在一起
Datnew.wid1(:,2:3) = newPoint.wid1;
Datnew.widst(:,2:3) = newPoint.widst;
Datnew.wid2(:,2:3) = newPoint.wid2;

% 真值接到插值后，形成总指纹库：真值+插值
Datrenew.wid1 = [Datre.wid1;Datnew.wid1];     Datrenew.widst = [Datre.widst;Datnew.widst];     Datrenew.wid2 = [Datre.wid2;Datnew.wid2];     
Datrenew.allwid = [Datrenew.wid1;Datrenew.widst;Datrenew.wid2];
Datrenew.allmid = [Datre.mid1;Datre.midst;Datre.mid2];
%% 
scatter(Datrenew.wid1(:,2),Datrenew.wid1(:,3),25,Datrenew.wid1(:,8), 'filled');
shading interp;
colormap('jet');
colorbar;

set(gca,'xgrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);% 灰色格网线
set(gca,'Ygrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);
set(gca,'XMinorTick','on'); % X轴打开密集坐标格网
set(gca,'YMinorTick','on'); % Y轴打开密集坐标格网
% title('反距离内插后磁场水平方向热力图');
xlabel('West-East(m)');
ylabel('South-North(m)');

%% 归一化
% 总训练集归一化
for i = 1:width(Datrenew.allwid)
    allPoint.mean(1,i)=mean(Datrenew.allwid(:,i));
    allPoint.sig(1,i)=std(Datrenew.allwid(:,i));
end

for j = 2:width(Datrenew.allwid)
    for i=1:length(Datrenew.allwid)
        Dattrain.all(i,j)=(Datrenew.allwid(i,j)-allPoint.mean(1,j))/allPoint.sig(1,j);
    end
end

Dattrain.x = Dattrain.all(:,[5:7,13:end]);
Dattrain.y = Dattrain.all(:,2:4);
% 测试集归一化

for j = 2:width(Datrenew.allmid)
%     for i=1:length(Datrenew.allmid)
%         Dattest.all(i,j)=(Datrenew.allmid(i,j)-allPoint.mean(1,j))/allPoint.sig(1,j);
%     end
    for i=1:size(Datrenew.allmid,1)
        Dattest.all(i,j)=(Datrenew.allmid(i,j)-allPoint.mean(1,j))/allPoint.sig(1,j);
    end
end
Dattest.x = Dattest.all(:,[5:7,13:end]);
Dattest.y = Dattest.all(:,2:4);
%% 随机森林
numTrees=50;
mdx = TreeBagger(numTrees,Dattrain.x,Dattrain.y(:,1),'method','regression','MinLeafSize',1,'OOBVarImp','on','FBoot',1);
mdy = TreeBagger(numTrees,Dattrain.x,Dattrain.y(:,2),'method','regression','MinLeafSize',1,'OOBVarImp','on','FBoot',1);
mdz = TreeBagger(numTrees,Dattrain.x,Dattrain.y(:,3),'method','regression','MinLeafSize',1,'OOBVarImp','on','FBoot',1);

%测试 预测
Px=predict(mdx,Dattest.x);
Py=predict(mdy,Dattest.x);
Pz=predict(mdz,Dattest.x);

Px=Px*allPoint.sig(1,2)+allPoint.mean(1,2);
Py=Py*allPoint.sig(1,3)+allPoint.mean(1,3);
Pz=Pz*allPoint.sig(1,4)+allPoint.mean(1,4);

hold on
axis equal

% plot(Datre_wid.data(:,2),Datre_wid.data(:,3),'linewidth',2,'color','b');
plot3(Datrenew.allmid(:,2),Datrenew.allmid(:,3),Datrenew.allmid(:,4),'linewidth',2.5,'color',[1, 0.5, 0.2]);
plot3(Px,Py,Pz,'linewidth',1.5,'color','r');
scatter(Px(1),Py(1),30,'g','filled');
% scatter(Px(50:80),Py(50:80),30,'g','filled');
% scatter(Px(80:120),Py(80:120),30,'g','filled');
% scatter(Px(150:180),Py(150:180),30,'g','filled');
legend('楼道边界','真实轨迹','匹配轨迹','匹配轨迹起点')
set(gca,'xgrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);% 灰色格网线
set(gca,'Ygrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);
set(gca,'XMinorTick','on'); % X轴打开密集坐标格网
set(gca,'YMinorTick','on'); % Y轴打开密集坐标格网


xlabel('West-East(m)');
ylabel('South-North(m)');

RMSEx=sqrt(sum((Datrenew.allmid(:,2) - Px).^2) ./ length(Px));
RMSEy=sqrt(sum((Datrenew.allmid(:,3) - Py).^2) ./ length(Py));
RMSEz=sqrt(sum((Datrenew.allmid(:,4) - Pz).^2) ./ length(Pz));
error1 = sqrt(RMSEx^2 + RMSEy^2);

string = {strcat('测试集预测结果对比：', ['RMSE=' num2str(error1)])};
title(string)
disp(error1);
disp(RMSEz);


%% LSTM
%%
layers = [
    sequenceInputLayer(167,"Name","input")
    lstmLayer(200,"Name","lstm")
    dropoutLayer(0.1,"Name","drop")
    lstmLayer(200,"Name","lstm")
    dropoutLayer(0.1,"Name","drop")
    fullyConnectedLayer(50,"Name","fc")
    fullyConnectedLayer(3,"Name","fc")
    regressionLayer("Name","regressionoutput")];
options = trainingOptions('adam', ...
    'MaxEpochs',250, ...
    'GradientThreshold',1, ...
    'InitialLearnRate',0.005, ...
    'LearnRateSchedule','piecewise', ...
    'LearnRateDropPeriod',125, ...
    'LearnRateDropFactor',0.2, ...
    'Verbose',1, ...
    'MiniBatchSize',3, ...
    'Plots','training-progress'); 

net = trainNetwork(Dattrain.x',Dattrain.y',layers,options); 

%%
netupdate = predictAndUpdateState(net,Dattrain.x');
%%
XTest=Dattest.x';
numTimeStepsTest = numel(XTest(1,:));

for i = 1:numTimeStepsTest
    [netupdate,YPred(:,i)] = predictAndUpdateState(netupdate,XTest(:,i),'ExecutionEnvironment','cpu');
end 
%%
Px = YPred(1,:)*allPoint.sig(1,2)+allPoint.mean(1,2);
Py = YPred(2,:)*allPoint.sig(1,3)+allPoint.mean(1,3);
Pz = YPred(3,:)*allPoint.sig(1,4)+allPoint.mean(1,4);

Px = Px'; Py = Py'; Pz = Pz'; 

hold on
axis equal
% plot(Datre_wid.data(:,2),Datre_wid.data(:,3),'linewidth',2,'color','b');
plot3(Datrenew.allmid(:,2),Datrenew.allmid(:,3),Datrenew.allmid(:,4),'linewidth',2.5,'color',[1, 0.5, 0.2]);
plot3(Px,Py,Pz,'linewidth',1.5,'color','r');
scatter(Px(1),Py(1),50,'g','filled');
legend('楼道边界','真实轨迹','匹配轨迹','匹配轨迹起点')
set(gca,'xgrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);% 灰色格网线
set(gca,'Ygrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);
set(gca,'XMinorTick','on'); % X轴打开密集坐标格网
set(gca,'YMinorTick','on'); % Y轴打开密集坐标格网


xlabel('West-East(m)');
ylabel('South-North(m)');
RMSEx=sqrt(sum((Datrenew.allmid(:,2) - Px).^2) ./ length(Px));
RMSEy=sqrt(sum((Datrenew.allmid(:,3) - Py).^2) ./ length(Py));
RMSEz=sqrt(sum((Datrenew.allmid(:,4) - Pz).^2) ./ length(Pz));
error1 = sqrt(RMSEx^2 + RMSEy^2);

string = {strcat('LSTM测试集预测结果对比：', ['RMSE=' num2str(error1)])};
title(string)
disp(RMSEx);
disp(RMSEy);

%% 误差反传 BP
YPred=BP(Dattrain.x,Dattrain.y,Dattest.x);

Px = YPred(1,:)*allPoint.sig(1,2)+allPoint.mean(1,2); Px=Px';
Py = YPred(2,:)*allPoint.sig(1,3)+allPoint.mean(1,3); Py=Py';
Pz = YPred(3,:)*allPoint.sig(1,4)+allPoint.mean(1,4); Pz=Pz';

hold on
axis equal
% plot(Datre_wid.data(:,2),Datre_wid.data(:,3),'linewidth',2,'color','b');
plot3(Datrenew.allmid(:,2),Datrenew.allmid(:,3),Datrenew.allmid(:,4),'linewidth',2.5,'color',[1, 0.5, 0.2]);
plot3(Px,Py,Pz,'linewidth',1.5,'color','r');
scatter(Px(1),Py(1),50,'g','filled');
legend('楼道边界','真实轨迹','匹配轨迹','匹配轨迹起点')
set(gca,'xgrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);% 灰色格网线
set(gca,'Ygrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);
set(gca,'XMinorTick','on'); % X轴打开密集坐标格网
set(gca,'YMinorTick','on'); % Y轴打开密集坐标格网


xlabel('West-East(m)');
ylabel('South-North(m)');
RMSEx=sqrt(sum((Datrenew.allmid(:,2) - Px).^2) ./ length(Px));
RMSEy=sqrt(sum((Datrenew.allmid(:,3) - Py).^2) ./ length(Py));
RMSEz=sqrt(sum((Datrenew.allmid(:,4) - Pz).^2) ./ length(Pz));
error1 = sqrt(RMSEx^2 + RMSEy^2);

string = {strcat('BP测试集预测结果对比：', ['RMSE=' num2str(error1)])};
title(string)
disp(RMSEx);
disp(RMSEy);

%% 支持向量机 SVM
YPred = SVM(Dattrain.x,Dattrain.y,Dattest.x,Dattest.y);

Px = YPred(:,1)*allPoint.sig(1,2)+allPoint.mean(1,2); 
Py = YPred(:,2)*allPoint.sig(1,3)+allPoint.mean(1,3); 
Pz = YPred(:,3)*allPoint.sig(1,4)+allPoint.mean(1,4); 

hold on
axis equal
% plot(Datre_wid.data(:,2),Datre_wid.data(:,3),'linewidth',2,'color','b');
plot3(Datrenew.allmid(:,2),Datrenew.allmid(:,3),Datrenew.allmid(:,4),'linewidth',2.5,'color',[1, 0.5, 0.2]);
plot3(Px,Py,Pz,'linewidth',1.5,'color','r');
scatter(Px(1),Py(1),50,'g','filled');
legend('楼道边界','真实轨迹','匹配轨迹','匹配轨迹起点')
set(gca,'xgrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);% 灰色格网线
set(gca,'Ygrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);
set(gca,'XMinorTick','on'); % X轴打开密集坐标格网
set(gca,'YMinorTick','on'); % Y轴打开密集坐标格网

xlabel('West-East(m)');
ylabel('South-North(m)');
RMSEx=sqrt(sum((Datrenew.allmid(:,2) - Px).^2) ./ length(Px));
RMSEy=sqrt(sum((Datrenew.allmid(:,3) - Py).^2) ./ length(Py));
RMSEz=sqrt(sum((Datrenew.allmid(:,4) - Pz).^2) ./ length(Pz));
error1 = sqrt(RMSEx^2 + RMSEy^2);

string = {strcat('SVM测试集预测结果对比：', ['RMSE=' num2str(error1)])};
title(string)
disp(RMSEx);
disp(RMSEy);

%% CNN
YPred = CNN(Dattrain.x,Dattrain.y,Dattest.x);
%%
Px=YPred(:,1)*allPoint.sig(1,2)+allPoint.mean(1,2);
Py=YPred(:,2)*allPoint.sig(1,3)+allPoint.mean(1,3);
Pz = YPred(:,3)*allPoint.sig(1,4)+allPoint.mean(1,4); 

hold on
axis equal
% plot(Datre_wid.data(:,2),Datre_wid.data(:,3),'linewidth',2,'color','b');
plot3(Datrenew.allmid(:,2),Datrenew.allmid(:,3),Datrenew.allmid(:,4),'linewidth',2.5,'color',[1, 0.5, 0.2]);
plot3(Px,Py,Pz,'linewidth',1.5,'color','r');
scatter(Px(1),Py(1),50,'g','filled');
legend('楼道边界','真实轨迹','匹配轨迹','匹配轨迹起点')
set(gca,'xgrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);% 灰色格网线
set(gca,'Ygrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);
set(gca,'XMinorTick','on'); % X轴打开密集坐标格网
set(gca,'YMinorTick','on'); % Y轴打开密集坐标格网

xlabel('West-East(m)');
ylabel('South-North(m)');
RMSEx=sqrt(sum((Datrenew.allmid(:,2) - Px).^2) ./ length(Px));
RMSEy=sqrt(sum((Datrenew.allmid(:,3) - Py).^2) ./ length(Py));
RMSEz=sqrt(sum((Datrenew.allmid(:,4) - Pz).^2) ./ length(Pz));
error1 = sqrt(RMSEx^2 + RMSEy^2);

string = {strcat('CNN测试集预测结果对比：', ['RMSE=' num2str(error1)])};
title(string)

disp(RMSEx);
disp(RMSEy);

%% LSTM2
YPred = LSTM2(Dattrain.x,Dattrain.y,Dattest.x);

Px = YPred(:,1)*allPoint.sig(1,2)+allPoint.mean(1,2);
Py = YPred(:,2)*allPoint.sig(1,3)+allPoint.mean(1,3);
Pz = YPred(:,3)*allPoint.sig(1,4)+allPoint.mean(1,4); 

hold on
axis equal
% plot(Datre_wid.data(:,2),Datre_wid.data(:,3),'linewidth',2,'color','b');
plot3(Datrenew.allmid(:,2),Datrenew.allmid(:,3),Datrenew.allmid(:,4),'linewidth',2.5,'color',[1, 0.5, 0.2]);
plot3(Px,Py,Pz,'linewidth',1.5,'color','r');
scatter(Px(1),Py(1),50,'g','filled');
legend('楼道边界','真实轨迹','匹配轨迹','匹配轨迹起点')
set(gca,'xgrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);% 灰色格网线
set(gca,'Ygrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);
set(gca,'XMinorTick','on'); % X轴打开密集坐标格网
set(gca,'YMinorTick','on'); % Y轴打开密集坐标格网

xlabel('West-East(m)');
ylabel('South-North(m)');
RMSEx=sqrt(sum((Datrenew.allmid(:,2) - Px).^2) ./ length(Px));
RMSEy=sqrt(sum((Datrenew.allmid(:,3) - Py).^2) ./ length(Py));
RMSEz=sqrt(sum((Datrenew.allmid(:,4) - Pz).^2) ./ length(Pz));
error1 = sqrt(RMSEx^2 + RMSEy^2);

string = {strcat('LSTM测试集预测结果对比：', ['RMSE=' num2str(error1)])};
title(string)

disp(RMSEx);
disp(RMSEy);

%% 极限学习机
YPred = ExLearn(Dattrain.x,Dattrain.y,Dattest.x);

Px = YPred(1,:)*allPoint.sig(1,2)+allPoint.mean(1,2); Px=Px';
Py = YPred(2,:)*allPoint.sig(1,3)+allPoint.mean(1,3); Py=Py';
Pz = YPred(3,:)*allPoint.sig(1,4)+allPoint.mean(1,4); Pz=Pz';

hold on
axis equal
% plot(Datre_wid.data(:,2),Datre_wid.data(:,3),'linewidth',2,'color','b');
plot3(Datrenew.allmid(:,2),Datrenew.allmid(:,3),Datrenew.allmid(:,4),'linewidth',2.5,'color',[1, 0.5, 0.2]);
plot3(Px,Py,Pz,'linewidth',1.5,'color','r');
scatter(Px(1),Py(1),50,'g','filled');
legend('楼道边界','真实轨迹','匹配轨迹','匹配轨迹起点')
set(gca,'xgrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);% 灰色格网线
set(gca,'Ygrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);
set(gca,'XMinorTick','on'); % X轴打开密集坐标格网
set(gca,'YMinorTick','on'); % Y轴打开密集坐标格网

xlabel('West-East(m)');
ylabel('South-North(m)');
RMSEx=sqrt(sum((Datrenew.allmid(:,2) - Px).^2) ./ length(Px));
RMSEy=sqrt(sum((Datrenew.allmid(:,3) - Py).^2) ./ length(Py));
RMSEz=sqrt(sum((Datrenew.allmid(:,4) - Pz).^2) ./ length(Pz));
error1 = sqrt(RMSEx^2 + RMSEy^2);

string = {strcat('极限学习机测试集预测结果对比：', ['RMSE=' num2str(error1)])};
title(string)

disp(RMSEx);
disp(RMSEy);

%% 偏最小二乘算法
YPred = PLS(Dattrain.x,Dattrain.y,Dattest.x);

Px = YPred(:,1)*allPoint.sig(1,2)+allPoint.mean(1,2);
Py = YPred(:,2)*allPoint.sig(1,3)+allPoint.mean(1,3);
Pz = YPred(:,3)*allPoint.sig(1,4)+allPoint.mean(1,4); 

hold on
axis equal
% plot(Datre_wid.data(:,2),Datre_wid.data(:,3),'linewidth',2,'color','b');
plot3(Datrenew.allmid(:,2),Datrenew.allmid(:,3),Datrenew.allmid(:,4),'linewidth',2.5,'color',[1, 0.5, 0.2]);
plot3(Px,Py,Pz,'linewidth',1.5,'color','r');
scatter(Px(1),Py(1),50,'g','filled');
legend('楼道边界','真实轨迹','匹配轨迹','匹配轨迹起点')
set(gca,'xgrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);% 灰色格网线
set(gca,'Ygrid','on','GridLineStyle','-','GridColor',[0.80392 0.78824 0.78824], 'GridAlpha',0.2);
set(gca,'XMinorTick','on'); % X轴打开密集坐标格网
set(gca,'YMinorTick','on'); % Y轴打开密集坐标格网

xlabel('West-East(m)');
ylabel('South-North(m)');
RMSEx=sqrt(sum((Datrenew.allmid(:,2) - Px).^2) ./ length(Px));
RMSEy=sqrt(sum((Datrenew.allmid(:,3) - Py).^2) ./ length(Py));
RMSEz=sqrt(sum((Datrenew.allmid(:,4) - Pz).^2) ./ length(Pz));
error1 = sqrt(RMSEx^2 + RMSEy^2);

string = {strcat('偏最小二乘法测试集预测结果对比：', ['RMSE=' num2str(error1)])};
title(string)

disp(RMSEx);
disp(RMSEy);