function [Wifi_wid,Wifi_mid]=Datin_wifi(wid_s_e,mid_s_e)

wifiall=readtable('Dat/wifi.csv','Delimiter', ',');

widflag = [0;0;0;0;0;0]; midflag = [0;0;0;0];

for i=1:height(wifiall)
%     wifiall.Var4(i)=dbm2mw(wifiall.Var4(i));
    if wifiall.Var1(i) >= wid_s_e(1) && wifiall.Var1(i) <= wid_s_e(6) + 1
        if wifiall.Var1(i) == wid_s_e(1) && widflag(1) == 0
            wifi_wid_s_e(1) = i; widflag(1) = 1;
        elseif wifiall.Var1(i) == wid_s_e(2)+1 && widflag(2) == 0
            wifi_wid_s_e(2) = i-1; widflag(2) = 1;
        elseif wifiall.Var1(i) == wid_s_e(3)+1 && widflag(3) == 0
            wifi_wid_s_e(3) = i-1; widflag(3) = 1;
        elseif wifiall.Var1(i) == wid_s_e(4)+1 && widflag(4) == 0
            wifi_wid_s_e(4) = i-1; widflag(4) = 1;
        elseif wifiall.Var1(i) == wid_s_e(5)+1 && widflag(5) == 0
            wifi_wid_s_e(5) = i-1; widflag(5) = 1;
        elseif wifiall.Var1(i) == wid_s_e(6)+1 && widflag(6) == 0
            wifi_wid_s_e(6) = i-1; widflag(6) = 1;
        end
    end
    
    if wifiall.Var1(i) >= mid_s_e(1) && wifiall.Var1(i) <= mid_s_e(4) + 1
        if wifiall.Var1(i) == mid_s_e(1) && midflag(1) == 0
            wifi_mid_s_e(1) = i; midflag(1) = 1;
        elseif wifiall.Var1(i) == mid_s_e(2)+1 && midflag(2) == 0
            wifi_mid_s_e(2) = i-1; midflag(2) = 1;
        elseif wifiall.Var1(i) == mid_s_e(3)+1 && midflag(3) == 0
            wifi_mid_s_e(3) = i-1; midflag(3) = 1;
        elseif wifiall.Var1(i) == mid_s_e(4)+1 && midflag(4) == 0
            wifi_mid_s_e(4) = i-1; midflag(4) = 1;
        end
    end
end

widstart = wifi_wid_s_e(1); widend = wifi_wid_s_e(6);     %206-1492-1915-3632-4148-5580     21023-(67938,67967)-(88532,88587)-(176221,176267)-(198433,198447)-247149
midstart = wifi_mid_s_e(1); midend = wifi_mid_s_e(4);    %5597-7210-7747-8760            247680-(304625,304671)-(329975,330033)-385332
% midstart=385509; midend=60097;   %8765-9680-10092-11151           385509-(433918,433970)-(451679,451692)-488762

wifi_mid=wifiall(midstart:midend,:);
wifi_wid=wifiall(widstart:widend,:);
wifi_midgroup = wid_s_e(6);
wifi_widgroup = wid_s_e(1);

%去除BUAA
index_to_remove = contains(wifi_wid.Var2, 'BUAA');
wifi_wid(index_to_remove, :) = [];
uni_wid=unique(wifi_wid.Var3);

index_to_remove = contains(wifi_mid.Var2, 'BUAA');
wifi_mid(index_to_remove, :) = [];
uni_mid=unique(wifi_mid.Var3);

Wifi_wid.title=uni_wid;

% 去除wid和mid中的地址不同项
% diffAB = setdiff(uni_wid, uni_mid);%wid有，mid没有
% diffBA = setdiff(uni_mid, uni_wid);%mid有，wid没有

% index_to_remove=contains(wifi_wid.Var3,diffAB);
% wifi_wid(index_to_remove, :) = [];
uni_wid=unique(wifi_wid.Var3);

% index_to_remove = contains(wifi_mid.Var3, diffBA);
% wifi_mid(index_to_remove, :) = [];
uni_mid=unique(wifi_mid.Var3);

Wifi_wid.title=uni_wid;
Wifi_mid.title=uni_mid;

tempgroup=1;
for i=1:height(wifi_wid)
    if wifi_wid.Var1(i)~=wifi_widgroup
        wifi_widgroup=wifi_widgroup+1;
        tempgroup=tempgroup+1;
    end
    if wifi_wid.Var1(i)==wifi_widgroup
%         Wifi_wid.data(tempgroup,1)=wifi_widgroup;
        for j=1:length(uni_wid)
            if wifi_wid.Var3{i}==uni_wid{j,1}
                Wifi_wid.data(tempgroup,j)=wifi_wid.Var4(i);
            end
        end
    end
%     key = wifi_wid.Var3{i};
%     if isKey(uni_wid_map, key)
%         columnIndex = uni_wid_map(key);
%         Wifi_wid.data(tempgroup, columnIndex) = wifi_wid.Var4(i);
%     end
end

tempgroup=1;
for i=1:height(wifi_mid)
    if wifi_mid.Var1(i)~=wifi_midgroup
        wifi_midgroup=wifi_midgroup+1;
        tempgroup=tempgroup+1;
    end
    if wifi_mid.Var1(i)==wifi_midgroup
%         Wifi_mid.data(tempgroup,1)=wifi_midgroup;
        for j=1:length(uni_mid)
            if wifi_mid.Var3{i}==uni_mid{j,1}
                Wifi_mid.data(tempgroup,j)=wifi_mid.Var4(i);
            end
        end
    end
end

% sm=1;
% if sm==1
%     span = 10; degree = 1;
%     for i=1:width(Wifi_wid.data)
%         Wifi_wid.data(:,i) = smooth(Wifi_wid.data(:,i) ,span,'sgolay',degree);
%         Wifi_mid.data(:,i) = smooth(Wifi_mid.data(:,i) ,span,'sgolay',degree);
%     end
% end

% wifi.wid1 = [loc_datin(wid_s_e(1):wid_s_e(2),:);loc_datin(wid_s_e(5)+1:wid_s_e(6),:)];
% wifi.widst = [loc_datin(wid_s_e(2)+1:wid_s_e(3),:);loc_datin(wid_s_e(4)+1:wid_s_e(5),:)];
% wifi.wid2 = loc_datin(wid_s_e(3)+1:wid_s_e(4),:);
% wifi.mid1 = loc_datin(mid_s_e(1):mid_s_e(2),:);
% wifi.midst = loc_datin(mid_s_e(2)+1:mid_s_e(3),:);
% wifi.mid2 = loc_datin(mid_s_e(3)+1:mid_s_e(4),:);

end

function mw=dbm2mw(dbm)
    mw=10^(dbm/10);
end

