function [newdata]=Dis_in(Pointre_len,Pointre_num,Datre,newPoint)
% newdata=zeros(length(newPoint),width(Re_data));
for i=1:length(newPoint.wid1)
    for j=5:width(Datre.wid1)
        if j == 8
            newdata.wid1(i,j)=sqrt(newdata.wid1(i,5)^2+newdata.wid1(i,6).^2);
        elseif j < 8
            data1=Datre.wid1(Pointre_num.wid1(i,1),j);
            data2=Datre.wid1(Pointre_num.wid1(i,2),j);
            data3=Datre.wid1(Pointre_num.wid1(i,3),j);
            data4=Datre.wid1(Pointre_num.wid1(i,4),j);
            newdata.wid1(i,j)=Magin(Pointre_len.wid1(i,1),Pointre_len.wid1(i,2),Pointre_len.wid1(i,3),Pointre_len.wid1(i,4),data1,data2,data3,data4,1);
        elseif j >= 13
            data1=Datre.wid1(Pointre_num.wid1(i,1),j);
            data2=Datre.wid1(Pointre_num.wid1(i,2),j);
            data3=Datre.wid1(Pointre_num.wid1(i,3),j);
            data4=Datre.wid1(Pointre_num.wid1(i,4),j);
            newdata.wid1(i,j)=Magin(Pointre_len.wid1(i,1),Pointre_len.wid1(i,2),Pointre_len.wid1(i,3),Pointre_len.wid1(i,4),data1,data2,data3,data4,2);
        else 
            data1=Datre.wid1(Pointre_num.wid1(i,1),j);
            data2=Datre.wid1(Pointre_num.wid1(i,2),j);
            data3=Datre.wid1(Pointre_num.wid1(i,3),j);
            data4=Datre.wid1(Pointre_num.wid1(i,4),j);
            newdata.wid1(i,j)=Magin(Pointre_len.wid1(i,1),Pointre_len.wid1(i,2),Pointre_len.wid1(i,3),Pointre_len.wid1(i,4),data1,data2,data3,data4,1);
        end
    end
end
newdata.wid1(:,4) = 0;

for i=1:length(newPoint.widst)    %%楼梯部分的高度通过插值得出
    for j=4:width(Datre.widst) 
        if j == 8
            newdata.widst(i,j)=sqrt(newdata.widst(i,5)^2+newdata.widst(i,6).^2);
        elseif j < 8
            data1=Datre.widst(Pointre_num.widst(i,1),j);
            data2=Datre.widst(Pointre_num.widst(i,2),j);
            data3=Datre.widst(Pointre_num.widst(i,3),j);
            data4=Datre.widst(Pointre_num.widst(i,4),j);
            newdata.widst(i,j)=Magin(Pointre_len.widst(i,1),Pointre_len.widst(i,2),Pointre_len.widst(i,3),Pointre_len.widst(i,4),data1,data2,data3,data4,1);
        elseif j >= 13
            data1=Datre.widst(Pointre_num.widst(i,1),j);
            data2=Datre.widst(Pointre_num.widst(i,2),j);
            data3=Datre.widst(Pointre_num.widst(i,3),j);
            data4=Datre.widst(Pointre_num.widst(i,4),j);
            newdata.widst(i,j)=Magin(Pointre_len.widst(i,1),Pointre_len.widst(i,2),Pointre_len.widst(i,3),Pointre_len.widst(i,4),data1,data2,data3,data4,2);
        else
            data1=Datre.widst(Pointre_num.widst(i,1),j);
            data2=Datre.widst(Pointre_num.widst(i,2),j);
            data3=Datre.widst(Pointre_num.widst(i,3),j);
            data4=Datre.widst(Pointre_num.widst(i,4),j);
            newdata.widst(i,j)=Magin(Pointre_len.widst(i,1),Pointre_len.widst(i,2),Pointre_len.widst(i,3),Pointre_len.widst(i,4),data1,data2,data3,data4,1);
        end
    end
end

for i=1:length(newPoint.wid2)    
    for j=4:width(Datre.wid2) 
        if j == 8
            newdata.wid2(i,j)=sqrt(newdata.wid2(i,5)^2+newdata.wid2(i,6).^2);
        elseif j < 8
            data1=Datre.wid2(Pointre_num.wid2(i,1),j);
            data2=Datre.wid2(Pointre_num.wid2(i,2),j);
            data3=Datre.wid2(Pointre_num.wid2(i,3),j);
            data4=Datre.wid2(Pointre_num.wid2(i,4),j);
            newdata.wid2(i,j)=Magin(Pointre_len.wid2(i,1),Pointre_len.wid2(i,2),Pointre_len.wid2(i,3),Pointre_len.wid2(i,4),data1,data2,data3,data4,1);
        elseif j >= 13
            data1=Datre.wid2(Pointre_num.wid2(i,1),j);
            data2=Datre.wid2(Pointre_num.wid2(i,2),j);
            data3=Datre.wid2(Pointre_num.wid2(i,3),j);
            data4=Datre.wid2(Pointre_num.wid2(i,4),j);
            newdata.wid2(i,j)=Magin(Pointre_len.wid2(i,1),Pointre_len.wid2(i,2),Pointre_len.wid2(i,3),Pointre_len.wid2(i,4),data1,data2,data3,data4,2);
        else 
            data1=Datre.wid2(Pointre_num.wid2(i,1),j);
            data2=Datre.wid2(Pointre_num.wid2(i,2),j);
            data3=Datre.wid2(Pointre_num.wid2(i,3),j);
            data4=Datre.wid2(Pointre_num.wid2(i,4),j);
            newdata.wid2(i,j)=Magin(Pointre_len.wid2(i,1),Pointre_len.wid2(i,2),Pointre_len.wid2(i,3),Pointre_len.wid2(i,4),data1,data2,data3,data4,1);
        end
    end
end
% newdata.wid2(:,4) = 3.6;

% for i=1:length(newdata)
%     for j=11:width(newdata)
%         if newdata(i,j)~=0
%             newdata(i,j)=mw2dbm(newdata(i,j));
%         end
%     end
% end

end

function outputM = Magin(l1,l2,l3,l4,M1,M2,M3,M4,p)
    outputM = 1/l1^p/(1/l1^p+1/l2^p+1/l3^p+1/l4^p)*M1+1/l2^p/(1/l1^p+1/l2^p+1/l3^p+1/l4^p)*M2+1/l3^p/(1/l1^p+1/l2^p+1/l3^p+1/l4^p)*M3+1/l4^p/(1/l1^p+1/l2^p+1/l3^p+1/l4^p)*M4;
end

function dbm=mw2dbm(mw)
    dbm=10*log10(mw);
end